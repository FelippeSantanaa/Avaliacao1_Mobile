package com.example.imc

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_history.*
import java.util.*


class History : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val sh = getSharedPreferences("IMC", Context.MODE_PRIVATE)
        var histList = sh.getString("Historico", "")
        var tkn = StringTokenizer(histList.toString(), ";")

        while (tkn.hasMoreTokens()) {

            var alt = tkn.nextToken()

            var peso = tkn.nextToken()

            var imc = peso!!.toDouble() / (alt!!.toDouble() * alt!!.toDouble())


            txtHistorico.append("Indice massa corporal:" + "\n")

            if (imc < 18.5) {
                txtHistorico.append("Classificação:Magreza" + "\n")
                txtHistorico.append("Grau:0" + "\n")
            } else if ((imc > 18.5) && (imc < 24.9)) {
                txtHistorico.append("Classificação:Normal" + "\n")
                txtHistorico.append("Grau:0" + "\n")
            } else if ((imc > 25.0) && (imc < 29.9)) {
                txtHistorico.append("Classificação:Sobrepeso" + "\n")
                txtHistorico.append("Grau:1" + "\n")
            } else if ((imc > 30.0) && (imc < 39.9)) {
                txtHistorico.append("Classificação:Obesidade" + "\n")
                txtHistorico.append("Grau:2" + "\n")
            } else {
                txtHistorico.append("Classificação:Obesidade Grave" + "\n")
                txtHistorico.append("Grau:3" + "\n")
            }
            txtHistorico.append("------------------------------------" + "\n")
        }
    }
}