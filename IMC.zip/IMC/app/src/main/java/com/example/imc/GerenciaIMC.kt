package com.example.imc

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_gerencia_i_m_c.*
import java.util.*

class GerenciaIMC : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gerencia_i_m_c)

        val sh = getSharedPreferences("IMC", Context.MODE_PRIVATE)

        btnCalcular.setOnClickListener { x: View? ->
            var validado = true;

            var valAltura = altura.text.toString().toDouble();
            var valPeso = peso.text.toString().toDouble();

            if (valAltura <= 0.0) {
                Toast.makeText(
                    this,
                    "Por favor informar valores positivos na Altura",
                    Toast.LENGTH_SHORT
                ).show();
                validado = false;
            }

            if (valPeso <= 0.0) {
                Toast.makeText(
                    this,
                    "Por favor informar valores positivos no Peso",
                    Toast.LENGTH_SHORT
                ).show();
                validado = false;
            }

            if (validado){
                var imc =  valPeso!!.toDouble() / (valAltura!!.toDouble() * valAltura!!.toDouble())
                txtCalculo.setText("IMC = "+String.format("%.2f",imc)+"kg/m2")
            }

        }

        btnRegistrar.setOnClickListener { x ->
            var validado = true;
            var valAltura = altura.text.toString().toDouble();
            var valPeso = peso.text.toString().toDouble();

            if (valAltura <= 0.0) {
                Toast.makeText(
                    this,
                    "Por favor informar valores positivos na Altura",
                    Toast.LENGTH_SHORT
                ).show();
                validado = false;
            }
            if (valPeso <= 0.0) {
                Toast.makeText(
                    this,
                    "Por favor informar valores positivos no Peso",
                    Toast.LENGTH_SHORT
                ).show();
                validado = false;
            }

            if (validado){

                var register = altura.text.toString() + ";" + peso.text.toString()

                sh.edit().putString("UltimoRegistro",register.toString()).apply()

                var histLista = sh.getString("Historico","")

                val str2 = StringBuilder()
                str2.append(histLista.toString()).append(";")
                str2.append(altura.text.toString()).append(";")
                str2.append(peso.text.toString()).append(";")

                sh.edit().putString("Historico",str2.toString()).apply()


                Toast.makeText(this,"Registrado com sucesso", Toast.LENGTH_SHORT).show()
                altura.setText("");
                peso.setText("");
                txtCalculo.setText("");
            }
        }

        historico.setOnClickListener { x ->
            val intent = Intent(this, History::class.java)
            startActivity(intent)

        }
    }


}